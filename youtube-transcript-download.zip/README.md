# YouTube Transcript Download

A Manifest V3 Chrome extension that adds a transcript download panel beside YouTube videos and a **Transcript** button below the player.

The generated visual identity is stored in `icons/`, including the transparent master logo, browser icon sizes, and `favicon.png`.

## Export formats

- **Structured text** — `(00:00 - 00:02) Sentence 1`
- **Markdown** — timestamped Markdown list
- **Original** — transcript text without timestamps
- **SRT** — standard subtitle file
- **JSON** — video metadata and millisecond timestamps

## Install in Chrome

1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select this project folder.
5. Open or refresh a YouTube video that has captions. The subtitles load automatically with visible progress.

## Browser packages

Run `npm run build` to generate:

- `dist/chromium` — Chrome, Chrome in light or dark appearance, Edge, Brave, Opera, Vivaldi, and other Chromium-based browsers.
- `dist/opera` — explicitly named Opera package using the same Chromium-compatible runtime.
- `dist/firefox` — Firefox Manifest V3 package with Firefox-specific extension metadata.
- `dist/safari-source` — Safari Web Extension source prepared for Apple's packager.

For Safari, run the command documented in `dist/safari-source/SAFARI.md`. Safari requires Apple's Web Extension Packager/Xcode (or App Store Connect packaging) to create the containing Safari app.

## Quality checks

Run `npm test` for unit, integration, regression, storage-compatibility, and browser-build tests. Repository policy requires every bug fix to include a regression test.

The panel appears in the right column beside the video. A compact **Transcript** button also appears with the controls below the video. When subtitles finish loading, choose an export format and use the dedicated export button that appears. If discovery or loading fails, use the **Retry** button shown in the panel.

The transcript preview follows video playback. The sentence currently being spoken receives a contrasting background and accent bar, and the preview scrolls to keep it visible.

Open **Advanced export** to customize the export title, content type, tags, and AI context/instructions, or enable an optional metadata header for plain and structured text files. After selecting any format, a five-segment export preview and copy action appear directly before the export button; the downloaded file still includes the complete transcript. Markdown and JSON exports include the structured context directly; SRT remains standards-compatible.

Advanced export values are saved automatically in Chrome's local extension storage and restored the next time the panel opens.

The interface follows the browser language automatically for English, Brazilian Portuguese, and French. Use the settings button in the panel header to override the interface language and choose **Follow system**, **Light**, or **Dark** appearance. These preferences are saved locally.

## How it works

The extension reads caption tracks exposed by YouTube in the active watch page. Its optional **Translate before downloading** control is off by default; when enabled, it requests the selected target language through YouTube's Google-powered caption translation before exporting. It also watches YouTube's `get_panel` response and understands the modern `transcriptSegmentViewModel` shape as a fallback. It never stores or copies account cookies, authorization headers, visitor IDs, or the captured cURL request.

YouTube is a frequently changing site. If its page internals change, reload the extension after updating these files and then refresh the watch page.
